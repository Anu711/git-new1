package com.example.springjdbcdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringjdbcdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
