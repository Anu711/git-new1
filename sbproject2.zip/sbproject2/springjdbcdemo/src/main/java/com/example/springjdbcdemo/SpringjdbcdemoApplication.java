package com.example.springjdbcdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class SpringjdbcdemoApplication {

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(SpringjdbcdemoApplication.class, args);
		Person p = context.getBean(Person.class);
		p.setId(111);
		p.setName("person1");
		p.setTech("java");

		personrepo pr = context.getBean(personrepo.class);
		pr.save(p);
		System.out.println(pr.findall());
		;

	}

}
