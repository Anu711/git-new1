package com.example.springjdbcdemo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class personrepo {

    private JdbcTemplate temp;

    public JdbcTemplate getTemp() {
        return temp;
    }

    @Autowired
    public void setTemp(JdbcTemplate temp) {
        this.temp = temp;
    }

    public void save(Person p1) {
        System.out.println("added");

        String sql = "INSERT INTO Person (id,name,tech) VALUES(116,'Rhys','AI')";

        int rows = temp.update(sql);
        System.out.println(rows + "rows affected ");
    }

    public List<Person> findall() {
        String sql1 = "SELECT * FROM Person";
        RowMapper<Person> personRowMapper = new RowMapper<Person>() {
            @Override
            public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
                Person person = new Person();
                person.setId(rs.getInt("id"));
                person.setName(rs.getString("name"));
                person.setTech(rs.getString("tech"));
                return person;
            }
        };
        List<Person> persons = temp.query(sql1, personRowMapper);
        return persons;
    }
}
