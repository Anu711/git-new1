/*this is file for default data */
insert into person(id,name,tech) values(112,"alex","aws");
insert into person(id,name,tech) values(113,"ava","devops");
insert into person(id,name,tech) values(114,"josh","azure");