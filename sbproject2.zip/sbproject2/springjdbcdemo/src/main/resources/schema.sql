/* this is the data.sql file wheere u will write the table code*/

Create table Person(
   int id Primary key,
   name Varchar(200),
   tech Varchar(50)

)

