package com.example.sbproject2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sbproject2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
