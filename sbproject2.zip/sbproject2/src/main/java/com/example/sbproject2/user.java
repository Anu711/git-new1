package com.example.sbproject2;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class user {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // to set primary key
    private Integer id;

    private String name;

    private String email;

    // Getter method for id
    public Integer getid() {
        return id;
    }

    // Setter method for id
    public void setid(Integer id) {
        this.id = id;
    }

    // Getter method for name
    public String getname() {
        return name;
    }

    // Setter method for name
    public void setname(String name) {
        this.name = name;
    }

    // Getter method for email
    public String getemail() {
        return email;
    }

    // Setter method for email
    public void setemail(String email) {
        this.email = email;
    }
}
