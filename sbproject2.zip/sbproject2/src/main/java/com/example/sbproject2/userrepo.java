package com.example.sbproject2;

import org.springframework.data.repository.CrudRepository;

public interface userrepo extends CrudRepository<user, Integer> {
    // this is autoimplemented by spring

}
