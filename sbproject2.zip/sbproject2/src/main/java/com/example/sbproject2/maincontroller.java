package com.example.sbproject2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@RestController

@RequestMapping(path="/SBPROJECT2")
public String requestMethodName(@RequestParam String param) {
    return new String();
}

public class maincontroller {
    // a controller is used to handle the http requests

    @Autowired
    private userrepo ur;

    @PostMapping("path")
    public String postMethodName(@RequestBody String entity) {
        //TODO: process POST request
        
        return entity;
    }
    
    public @ResponseBody user addUser(@RequestParam String name, @RequestParam String email) {
        user springUser = new user();
        springUser.setname(name);
        springUser.setemail(email);
        userrepo.save(springUser);
        return springUser;


    }
}
