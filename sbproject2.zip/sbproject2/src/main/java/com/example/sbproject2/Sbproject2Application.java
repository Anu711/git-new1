package com.example.sbproject2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sbproject2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sbproject2Application.class, args);
	}

}
